﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpIntroductionProgrammingAssignment
{
    class ParamArray
    {
        public static void Main()
        {
            int[] Numbers = { 100, 105, 130, 80, 120 };
            ParamsMethod(Numbers);

        }
        public static void ParamsMethod(params int[] Numbers)
        {
            int result;
            int sum = 0;
            for (int i = 0; i < Numbers.Length; i++)
            {
                sum = sum + Numbers[i];
            }
            result = sum;
            Console.WriteLine("The Result is:{0}", result);
        }
    }
}
