﻿using System;


class Calculator
{
    static void Main()
    {
        Console.WriteLine("Enter the FirstNumber:");
        int FirstNumber = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter the SecondNumber:");
        int SecondNumber = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("choose the operator(+,-,*,/)");

        int Result;

        switch (Console.ReadLine())
        {
            case "+":
                Result = FirstNumber + SecondNumber;
                Console.WriteLine("Addition of two number is:{0}", Result);
                break;
            case "-":
                Result = FirstNumber - SecondNumber;
                Console.WriteLine("Subtraction of two numbers is:{0}", Result);
                break;
            case "*":
                Result = FirstNumber * SecondNumber;
                Console.WriteLine("Multiplication of two numbers is:{0}", Result);
                break;
            case "/":
                Result = FirstNumber / SecondNumber;
                Console.WriteLine("Division of two numbers is:{0}", Result);
                break;
            default:
                Console.WriteLine("Enter a valid operator");
                break;



        }
    }
}