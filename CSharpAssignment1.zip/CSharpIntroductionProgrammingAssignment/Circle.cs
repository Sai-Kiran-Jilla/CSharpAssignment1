﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace CSharpIntroductionProgrammingAssignment
{
    class Circle
    {
        float Pi = 3.141F;
        int Radius;

        public Circle(int r)
        {
            this.Radius = r;
        }
        public float AreaOfTheCircle()
        {
            return this.Pi * this.Radius * this.Radius;
        }
        public float CircumferenceOfTheCircle()
        {
            int i = 2;
            return (i) * this.Pi * this.Radius;
        }
        public static void Main()
        {
            int value1 = Convert.ToInt32(Console.ReadLine());
            int value2 = Convert.ToInt32(Console.ReadLine());
            Circle C1 = new Circle(value1);
            float Area = C1.AreaOfTheCircle();

            Console.WriteLine("Area of the circle is:{0}", Area);

            Circle C2 = new Circle(value2);
            float Circumference = C2.CircumferenceOfTheCircle();

            Console.WriteLine("Circumference of the circle is:{0}", Circumference);

        }
    }
}