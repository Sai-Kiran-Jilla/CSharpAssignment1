﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpIntroductionProgrammingAssignment
{
    class Swap
    {
        public static void Main()
        {
            int FirstNumber = 10;
            int SecondNumber = 20;
            Swapping(ref FirstNumber, ref SecondNumber);
            Console.WriteLine("Swapped First Number is:{0}", FirstNumber);
            Console.WriteLine("Swapped Second Number is:{0}", SecondNumber);



        }
        public static void Swapping(ref int First, ref int Second)
        {
            int temp;
            temp = First;
            First = Second;
            Second = temp;


        }
    }
}
